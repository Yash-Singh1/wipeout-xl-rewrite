WipEout™ 2097 / WipEout™ XL | SLES-00327, SCUS-94351, SCPS-45078
Texture Pack - Version 2026/04/18


Information:
------------
This is an enhanced version of my WipEout 2097/XL texture pack released in 2020 for the RetroArch Beetle PSX HW core, reworked for DuckStation.
Made exclusively using Paint.net / Photoshop / Illustrator (no AI). Almost all textures are 16x their original resolution (2x for the title screen).
The pack replaces all 2D UI elements (BIOS/Menu/HUD).


Installation:
-------------
- Enable the "Enable Texture Replacement" and "Preload Texture Replacements" options in Settings > Graphics > Texture Replacement
- Move the texture folder to the DuckStation textures directory: .../DuckStation/textures/SCUS-94351
- If using the European or Japanese version of the game, replace the folder name "SCUS-94351" with one of the other serial numbers:

SLES-00327 | WipEout 2097 (Europe)
SCUS-94351 | WipEout XL (USA) [Default]
SCPS-45078 | ワイプアウトＸＬ (Japan)


Recommended settings:
---------------------
Internal Resolution: at least 9x Native
Aspect Ratio: PAR 1:1
Crop: All borders
PGXP Geometry Correction: Enabled
PGXP Depth Buffer: Enabled
Multi-Sampling: at least 4x MSAA or SSAA


Notes:
------
The shadows of the ships are distorted when PGXP is enabled, because DuckStation applies the "CPU Mode" PGXP setting automatically for WipEout 2097/XL.
It is forced regardless of user settings by the emulator.
Disabling "Apply Compatibility Settings" in "Settings > Advanced > Tweaks/Hacks" fixes this.